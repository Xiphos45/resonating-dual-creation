package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class GameCube extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_gamecube);
        ArrayList<Title> gameCube = new ArrayList<Title>();
        gameCube.add(new Title(R.drawable.gamecube, "Mario Kart Double Dash", "Row 1 from the top", "Column 6 from the left"));
        gameCube.add(new Title(R.drawable.gamecube, "Metriod Prime", "Row 15 & 16 from the top", "Column 6 from the left"));
        gameCube.add(new Title(R.drawable.gamecube, "Pikminn", "Row 2", "Column 2"));
        gameCube.add(new Title(R.drawable.gamecube, "Super Mario Sunshine", "Row 2", "Column 2"));
        gameCube.add(new Title(R.drawable.gamecube, "Tiger Woods PGA Tour 2004", "Row 2", "Column 2"));

        TitleAdapter adapter = new TitleAdapter(this, gameCube);
        ListView listView = (ListView) findViewById(R.id.list_gamecube);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int gamecubePosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (gamecubePosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (gamecubePosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}