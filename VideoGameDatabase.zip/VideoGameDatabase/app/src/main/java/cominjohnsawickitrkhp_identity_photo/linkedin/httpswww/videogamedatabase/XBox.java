package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class XBox extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_xbox);
        ArrayList<Title> xBox = new ArrayList<Title>();
        xBox.add(new Title(R.drawable.xbox, "Colin McRae Rally 3", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Counter Strike", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Forza Motorsport", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Halo", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Halo 2", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Nightfire (007)", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Panzer Dragoon Orta", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Pariah", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Project Gotham Racing 2", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "RalliSport Challenge", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Star Wares The Clone Wars", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Unreal Championship", "Row 1 from the top", "Column 6 from the left"));
        xBox.add(new Title(R.drawable.xbox, "Unreal Championship 2: Liandri Conflict", "Row 1 from the top", "Column 6 from the left"));

        TitleAdapter adapter = new TitleAdapter(this, xBox);
        ListView listView = (ListView) findViewById(R.id.list_xbox);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int xboxPosition = position;

                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (xboxPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (xboxPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}