package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/21/2016.
 */

public class Title {
    private int gameIcon;
    private String gameTitle;
    private String gameRow;
    private String gameColumn;


    public Title(int icon, String title, String row, String column) {
        gameIcon = icon;
        gameTitle = title;
        gameRow = row;
        gameColumn = column;

    }
    public int getGameIconId() {return gameIcon;}
    public String getGameTitle() {return gameTitle;}
    public String getGameRow() {return gameRow;}
    public String getGameColumn() {return gameColumn;}
}