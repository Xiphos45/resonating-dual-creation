package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class NES extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_nes);
        ArrayList<Title> nes = new ArrayList<Title>();
        nes.add(new Title(R.drawable.nes, "Bram Stoke's Dracula", "Row 1", "Column 1"));
        nes.add(new Title(R.drawable.nes, "Hunt for Red October, The", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Krusty's Fun House", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Micro Machines", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Operation Wolf", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Pac-Man (Arcade Version)", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Super Mario Bros. /Duck Hunt", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Super Mario Bros. 2", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Super Mario 3", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Super Mario 3", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Turtle II", "Row 2", "Column 2"));
        nes.add(new Title(R.drawable.nes, "Turtle III", "Row 2", "Column 2"));



        TitleAdapter adapter = new TitleAdapter(this, nes);
        ListView listView = (ListView) findViewById(R.id.list_nes);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int nesPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (nesPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (nesPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}