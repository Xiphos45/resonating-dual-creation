package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by John on 9/21/2016.
 */
public class TitleAdapter extends ArrayAdapter<Title> {
    private static final String LOG_TAG = TitleAdapter.class.getSimpleName();
    public TitleAdapter(Activity context, ArrayList<Title> words) {
        super(context, 0, words);   //has to be on the first line of the constructor
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_titles, parent, false);
        }
        Title titleList = getItem(position);

        ImageView iconImageView = (ImageView) listItemView.findViewById(R.id.icon_image_view);
        iconImageView.setVisibility(View.VISIBLE);
        iconImageView.setImageResource(titleList.getGameIconId());

        TextView titleTextView = (TextView) listItemView.findViewById(R.id.title_text_view);
        titleTextView.setText(titleList.getGameTitle());

        TextView rowTextView = (TextView) listItemView.findViewById(R.id.column_text_view);
        rowTextView.setText(titleList.getGameRow());

        TextView columnTextView = (TextView) listItemView.findViewById(R.id.row_text_view);
        columnTextView.setText(titleList.getGameColumn());





        return listItemView;
    }
}
