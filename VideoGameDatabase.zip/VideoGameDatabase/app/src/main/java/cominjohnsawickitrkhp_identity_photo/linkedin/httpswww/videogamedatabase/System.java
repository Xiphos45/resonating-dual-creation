package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/5/2016.
 */
public class System {
    private String mSystemName;
    private int mSystemImageId;

    public System(String sys, int imageId) {
        mSystemName = sys;
        mSystemImageId = imageId;
    }
    public String getSystemName() {
        return mSystemName;
    }

    public int getImageResourceId() {
        return mSystemImageId;
    }
}