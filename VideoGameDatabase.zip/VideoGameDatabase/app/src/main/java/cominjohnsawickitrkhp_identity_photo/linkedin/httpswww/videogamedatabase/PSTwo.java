package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class PSTwo extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_pstwo);
        ArrayList<Title> pstwo = new ArrayList<Title>();
        pstwo.add(new Title(R.drawable.pstwo, "Ace Combat: 04", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ace Combat 5: Unsung War", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Aggressive Inline", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Armored Core 2. Another Age", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "ATV Offroad Fury 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Baldur's Gate Dark Alliance", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Beyond Good & Evil", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Black", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Burnout 3: Takedown", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Burnout: Revenge", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDRMAX", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDRMAX 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDR Extreme", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDR Extreme 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDR Supernova", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDR Supernova 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "DDR X", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Deveil May Cry", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Final Fantasy X", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Final Fantasy XII", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Getaway, The", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "God of War", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "God of War II", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Grand Theft Auto San Andreas", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Grand Theft Auto Vice City", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Gran Tursimo 3: A-Spec", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Gran Turismo 4", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Guitar Hero", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Guitar Hero 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Guitar Hero 3: Legends of Rock", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Guitar Hero: Aerosmith", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "In the Groove", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Jack and Dexter: The Precursor Legacy", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Katamari Demacy", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Max Payne", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Max Payne 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "MDK 2 Armageddon", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Metal Arms: Glitch in the System", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Micro Machines v4", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Need for Speed : Hot Pursuit 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Need for Speed Most Wanted", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Need for Speed Underground", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Need for Speed Underground 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Onimusha 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Quake III", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ratchet & Clank", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ratchet & Clank: Deadlocked", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ratchet & Clank Going Commando", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ratchet & Clank Size Matters", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Ratchet & Clank Up Your Arsenal", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Red Faction", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "SSX 3", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Battlefront", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Battlefront II", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Bounty Hunter", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Jedi Starfighter", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Racer Revenge", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Star Wars Starfighter", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Syphon Filter: Dark Mirror", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Time Crisis 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Time Crisis 3", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Time Crisis: Crisis Zone", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Tony Hawk Pro Skater 3", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Tony Hawk Pro Skater 4", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Tony Hawks' Underground", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Tony Hawk's Underground 2", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Syphon Filter: The Omega Strain", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Unreal Tournament", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Wipeout Fusion", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "We <3 Katamari", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "World Rally Championship", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Xenosaga", "Row 1", "Column 1"));
        pstwo.add(new Title(R.drawable.pstwo, "Zone of the Enders The 2nd Runner", "Row 1", "Column 1"));

        TitleAdapter adapter = new TitleAdapter(this,pstwo);
        ListView listView = (ListView) findViewById(R.id.list_pstwo);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int pstwoPosition = position;

                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (pstwoPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (pstwoPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}