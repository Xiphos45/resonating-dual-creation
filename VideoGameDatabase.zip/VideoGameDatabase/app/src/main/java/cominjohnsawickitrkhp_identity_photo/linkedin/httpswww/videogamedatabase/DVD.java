package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/23/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class DVD extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_dvd);
        ArrayList<Title> dvd = new ArrayList<Title>();
        dvd.add(new Title(R.drawable.dvd, "How I meet Your Mother Season 2", "Column 1", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "How I meet Your Mother Season 3", "Column 1", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "How I meet Your Mother Season 4", "Column 1", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Las Vegas Season 1", "Column 1", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Las Vegas Season 2", "Column 1", "Row 3 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Las Vegas Season 3", "Column 1", "Row 3 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Las Vegas Season 4", "Column 1", "Row 3 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Cowboy Bebop Season 1", "Column 1", "Row 3 from the top"));
        dvd.add(new Title(R.drawable.dvd, "American Pie", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Ben-hur", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Dodgeball", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Enemy at the Gates", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Insomnia", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Lock, Stock, and Two Smoking Barrels", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Meet the Parents", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Mission Impossible 2", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Monty Pathon and the Holy Grail", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "The Mummy Returns", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Ocean's Eleven", "Column 2", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Ronin", "Column 7", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Pirates of the Caribbean: The Curse of the Black Pearl", "Column 7", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Pirates of the Caribbean: Dead Man's Chest", "Column 7", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Saving Private Ryan", "Column 7", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Snatch", "Column 7", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Spaceballs", "Column 9", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Starship Troopers", "Column 9", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Team America: World Police", "Column 9", "Row 1 from the top"));
        dvd.add(new Title(R.drawable.dvd, "Top Gun", "Column 9", "Row 1 from the top"));


        TitleAdapter adapter = new TitleAdapter(this, dvd);
        ListView listView = (ListView) findViewById(R.id.list_dvd);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int dvdPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (dvdPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (dvdPosition == 1) {      //1 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}
