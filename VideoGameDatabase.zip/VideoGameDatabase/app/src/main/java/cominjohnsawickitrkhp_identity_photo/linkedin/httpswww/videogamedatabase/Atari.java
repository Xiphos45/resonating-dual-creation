package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by John on 9/5/2016.
 */
public class Atari extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_atari);
        ArrayList<Title> atari = new ArrayList<Title>();
        atari.add(new Title(R.drawable.atari, "Asteroids", "Row 7 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Missile Command", "Row 7 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "(unknown)", "Row 7 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Breakout", "Row 7 from the bottom", "Column 4"));
        atari.add(new Title(R.drawable.atari, "Casino", "Row 7 from the bottom", "Column 4"));
        atari.add(new Title(R.drawable.atari, "Centipede", "Row 6 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Combat", "Row 6 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Defender", "Row 6 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Donkey Kong", "Row 6 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Indy 500", "Row 6 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Infiltrate", "Row 5 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Night Driver", "Row 5 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "(unknown)", "Row 5 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Pac-Man", "Row 5 from the bottom", "Column 4"));
        atari.add(new Title(R.drawable.atari, "Pac-Man", "Row 5 from the bottom", "Column 4"));
        atari.add(new Title(R.drawable.atari, "Space Invaders", "Row 4 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Space Invaders", "Row 4 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Surround", "Row 4 from the bottom", "Column 2"));
        atari.add(new Title(R.drawable.atari, "Video Olympics", "Row 4 from the bottom", "Column 3"));
        atari.add(new Title(R.drawable.atari, "Video Pinball", "Row 4 from the bottom", "Column 3"));


        TitleAdapter adapter = new TitleAdapter(this, atari);
        ListView listView = (ListView) findViewById(R.id.list_atari);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int atariPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (atariPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (atariPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}