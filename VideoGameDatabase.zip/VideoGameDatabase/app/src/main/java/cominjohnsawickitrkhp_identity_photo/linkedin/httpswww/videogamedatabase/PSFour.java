package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class PSFour extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_psfour);
        ArrayList<Title> psFour = new ArrayList<Title>();
        psFour.add(new Title(R.drawable.psfour, "Call of Duty Advanced Warfare", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Call of Duty Ghosts", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Dark Souls II", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Destiny", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Grand Theft Auto V", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Last of Us, The: Remasterd", "Row 1 from the top", "Column 6 from the left"));
        psFour.add(new Title(R.drawable.psfour, "Need for Speed Rivals", "Row 1 from the top", "Column 6 from the left"));



        TitleAdapter adapter = new TitleAdapter(this, psFour);
        ListView listView = (ListView) findViewById(R.id.list_psfour);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int psFourPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (psFourPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (psFourPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}