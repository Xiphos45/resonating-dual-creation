package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class SNES extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_snes);
        ArrayList<Title> snes = new ArrayList<Title>();
        snes.add(new Title(R.drawable.snes, "Batman Returns", "Row 1", "Column 1"));
        snes.add(new Title(R.drawable.snes, "Donkey Kong Country", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "Mortal Kombat", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "NBA Jam", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "Turtle IV", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "Super Mario Kart", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "Super Mario World", "Row 2", "Column 2"));
        snes.add(new Title(R.drawable.snes, "Street Fighter II", "Row 2", "Column 2"));


        TitleAdapter adapter = new TitleAdapter(this, snes);
        ListView listView = (ListView) findViewById(R.id.list_snes);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int snesPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (snesPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (snesPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}