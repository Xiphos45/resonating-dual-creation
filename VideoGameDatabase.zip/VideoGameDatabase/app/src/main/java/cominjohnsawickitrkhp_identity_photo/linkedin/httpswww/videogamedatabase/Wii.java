package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class Wii extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_wii);
        ArrayList<Title> wii = new ArrayList<Title>();
        wii.add(new Title(R.drawable.wii, "Legend of Zelda, The: Twilight Princess", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Mario Kart Wii", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "New Super Mario Bros. Wii", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Super Mario Galaxy", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Super Mario Galaxy 2", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Super Mario Party 8", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Star Wars: The Force Unleashed", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Wii Play", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Wii Sports", "Row 1 from the top", "Column 6 from the left"));
        wii.add(new Title(R.drawable.wii, "Wii Sports Resort", "Row 1 from the top", "Column 6 from the left"));

        TitleAdapter adapter = new TitleAdapter(this, wii);
        ListView listView = (ListView) findViewById(R.id.list_wii);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int wiiPosition = position;

                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if ( wiiPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if ( wiiPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}