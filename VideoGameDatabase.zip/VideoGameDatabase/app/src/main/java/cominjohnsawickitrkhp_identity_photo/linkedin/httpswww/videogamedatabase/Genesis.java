package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class Genesis extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_genesis);
        ArrayList<Title> genesis = new ArrayList<Title>();
        genesis.add(new Title(R.drawable.genesis, "Ecco the Dolphin", "Row 15 & 16 from the top", "Column 6 from the left"));
        genesis.add(new Title(R.drawable.genesis, "Eternal Champions", "Row 15 & 16 from the top", "Column 6 from the left"));
        genesis.add(new Title(R.drawable.genesis, "Jurrassic Park: Rampage Edition", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "NFL Football '94", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "NBA Jam", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Sonic the Hedgehog", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Sonic 2", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Sonic 3D Blasts", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Sonic & Knuckles", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Sonic Spinball", "Row 2", "Column 2"));
        genesis.add(new Title(R.drawable.genesis, "Taz-Mania", "Row 2", "Column 2"));

        TitleAdapter adapter = new TitleAdapter(this, genesis);
        ListView listView = (ListView) findViewById(R.id.list_genesis);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int genesisPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (genesisPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (genesisPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}