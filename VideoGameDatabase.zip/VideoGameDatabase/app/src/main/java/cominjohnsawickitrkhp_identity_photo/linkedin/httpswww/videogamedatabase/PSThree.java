package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class PSThree extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_psthree);
        ArrayList<Title> psThree = new ArrayList<Title>();
        psThree.add(new Title(R.drawable.psthree, "Assassin's Creed", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Assassin's Creed: Ezio Trilogy", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Batman: Arkham Asylum", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Batman: Arkham City", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Battlefield 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Battlefield Bad Company", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Bioshock 2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Bioshock Infinite", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Borderlands", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Brutal Legend", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Burnout Paradise", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Call of Duty: Modern Warfare 2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Crysis 2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Darksiders", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Diablo 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Doom 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "F1 2000", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Fallout 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Final Fantasy X | X-2 HD Remaster", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Final Fantasy XIII", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Final Fantaxt XIII-2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Gran Turismo 5", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Grand Theft Auto IV", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Jak and Dexter Collection", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Killzone 2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Mass Effect 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Metal Gear 4", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Minecraft", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Motorstorm", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Need for Speed Run", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Prince of Persia Trilogy", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Quake Wars", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ratchet & Clank Collection", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ratchet & Clank Future: A Crack in Time", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ratchet & Clank: All 4 One", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ratchet and Clank: Into the Nexus", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ratchet & Clank Future: Tools of Destruction", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Red Dead Redemption", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Red Fraction Armageddon", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Red Fraction Guerilla", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Resident Evil 5", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Resistance: Fall of Man", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Resistance 2", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Resistance 3", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Ridge Racer 7", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Saints Row The Third", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Skate", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "The Sly Collection", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Sonic Generations", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Split/ Second", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Tomb Raider", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Tomb Raider Trilogy", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Tomb Raider Underworld", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Uncharted: Drake's Fortune", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Uncharted 2: Among Thieves", "Row 1 from the top", "Column 6 from the left"));
        psThree.add(new Title(R.drawable.psthree, "Uncharted 3: Drake's Deception", "Row 1 from the top", "Column 6 from the left"));

        TitleAdapter adapter = new TitleAdapter(this, psThree);
        ListView listView = (ListView) findViewById(R.id.list_psthree);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int psthreePosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (psthreePosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (psthreePosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}