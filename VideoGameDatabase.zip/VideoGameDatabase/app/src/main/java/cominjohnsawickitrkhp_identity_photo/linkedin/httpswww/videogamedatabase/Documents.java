package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by John on 9/24/2016.
 */
public class Documents extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_documents);

        ArrayList<System> documentName = new ArrayList<System>();
        documentName.add(new System("ETV Block Diagram", R.drawable.etvpageone));
        documentName.add(new System("ETV General Arrangement", R.drawable.etvpagetwo));
        documentName.add(new System("ETV A/V Wiring Diagram", R.drawable.etvpagethree));
        documentName.add(new System("ETV Power and Controller Wiring Diagram Page 1", R.drawable.etvpagefour));
        documentName.add(new System("ETV Power and Controller Wiring Diagram Page 2", R.drawable.etvpagefive));
        documentName.add(new System("ETV A/V Input Selection Table", R.drawable.etvpagesix));
        documentName.add(new System("ETV 2 Year Spares", R.drawable.etvpageseven));
        documentName.add(new System("ETV Info", R.drawable.etvpageeight));
        documentName.add(new System("Bookcase Design Layout", R.drawable.tetrispageone));
        documentName.add(new System("Bookcase Wood Lengths", R.drawable.tetrispagetwo));
        documentName.add(new System("Block Diagram", R.drawable.tetrispagethree));


        DocumentAdapter sysAdapter = new DocumentAdapter(this, documentName);
        ListView listView = (ListView) findViewById(R.id.list_documents);
        listView.setAdapter(sysAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int drawingNumber = position;
                long systemID = id;
                // DO something
                if (drawingNumber == 0) {      //0 INDEX
                    //Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    //startActivity(documentIntent);
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("Block", 1);    //pass block to drawings class
                    startActivity(documentIntent);
                    //Toast toast = Toast.makeText(Documents.this, "block", Toast.LENGTH_LONG);
                    //toast.show();
                }
                if (drawingNumber == 1) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("ga", 2);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 2) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("av", 3);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 3) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("pc1", 4);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 4) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("pc2", 5);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 5) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("selection", 6);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 6) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("spares", 7);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 7) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("info", 8);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 8) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("design", 9);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 9) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("length", 10);    //pass block to drawings class
                    startActivity(documentIntent);
                }
                if (drawingNumber == 10) {      //0 INDEX
                    Intent documentIntent = new Intent(Documents.this, Drawings.class);
                    documentIntent.putExtra("diagram", 11);    //pass block to drawings class
                    startActivity(documentIntent);
                }
            }
        });
    }
}
