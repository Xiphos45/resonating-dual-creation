package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class XBoxThreeSixty extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_xboxthreesixty);
        ArrayList<Title> xBoxThreeSixty = new ArrayList<Title>();
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Ace Combat 6", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Armored Core For Answer", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Bioshock", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Beautiful Katamari", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Borderlands 2", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty  2", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty 3", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty 4", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty Black Ops", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty World at War", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Call of Duty Modern Warfare 3", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Defiance", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Fable 2", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Far Cry Predator", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Gears of War", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Gears of War 2", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Gears of War 3", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Halo 3", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Halo 4", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Halo ODST", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Halo Anniversary", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Halo Reach", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Guitar Hero Aerosmith", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Guitar Hero Metallica", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Guitar Hero World Tour", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Mass Effect 2", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Medal of Honor Airborne", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Need for Speed Carbon", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Need for Speed Hot Pursuit", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "The Orange Box", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Perfect Dark Zero", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Prey", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "PGR 3", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "PGR 4", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Quake 4", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Rockband", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Sonic Ultimate Genesis Collection", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Tiger Woods PGA Tour 2006", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Tekken 6", "Row 1 from the top", "Column 6 from the left"));
        xBoxThreeSixty.add(new Title(R.drawable.xboxthreesixty, "Unreal Tournament", "Row 1 from the top", "Column 6 from the left"));

        TitleAdapter adapter = new TitleAdapter(this, xBoxThreeSixty);
        ListView listView = (ListView) findViewById(R.id.list_xboxthreesixty);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int xBoxThreeSixty = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (xBoxThreeSixty == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (xBoxThreeSixty == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}