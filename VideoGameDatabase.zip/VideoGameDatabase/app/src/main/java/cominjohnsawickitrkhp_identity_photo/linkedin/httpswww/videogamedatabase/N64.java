package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class N64 extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_nsixtyfour);
        ArrayList<Title> nSixtyFour = new ArrayList<Title>();
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "1080 Degree", "Column 7", "Row 5 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Cruis'n USA", "Column 7", "Row 6 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Cruis'n World", "Column 7", "Row 6 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Diddy Kong Racing", "Column 7", "Row 6 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Donkey Kong 64", "Column 7", "Row 6 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "F-Zero X", "Column 7", "Row 7 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Goldeneye", "Column 8", "Row 7 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Harvest Moon 64", "Column 2", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Jet Force Gemini", "Column 7", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Mario Kart 64", "Column 7", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Micro Machine Turbo 64", "Column 7", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Mortal Kombat 4", "Column 7", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "New Tetris, The", "Column 7", "Row 8 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Perfect Dark", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Quake", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Pokemon Stadium", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "San Francisco Rush", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "San Fransico Rush 2", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "San Francisco Rush 2049", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Starfox 64", "Column 1", "Row 9 from the top"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Super Mario 64", "Column 7", "Row 9 from the bottom"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Super Smash Bros.", "Column 5", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Star Wars Episode 1 Racer", "Column 4", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Star Wars Rogue Squadron", "Column 4", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Turok 2", "Column 4", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Waverace 64", "Column 8", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "World is Not Enough, The", "Column 8", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Yoshi's Story", "Column 8", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Zelda (gray cassette)", "Column 5", "Column 1"));
        nSixtyFour.add(new Title(R.drawable.nsixtyfour, "Zelda (gold cassette)", "Column 8", "Column 1"));

        TitleAdapter adapter = new TitleAdapter(this,nSixtyFour);
        ListView listView = (ListView) findViewById(R.id.list_nsixtyfour);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int nSixtyFourPosition = position;

                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (nSixtyFourPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (nSixtyFourPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}