package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<System> systemName = new ArrayList<System>();
        systemName.add(new System("Atari", R.drawable.atari));
        systemName.add(new System("NES", R.drawable.nes));
        systemName.add(new System("Genesis", R.drawable.genesis));
        systemName.add(new System("SNES", R.drawable.snes));
        systemName.add(new System("PS1", R.drawable.psone));
        systemName.add(new System("N64", R.drawable.nsixtyfour));
        systemName.add(new System("Dreamcast", R.drawable.dreamcast));
        systemName.add(new System("PS2", R.drawable.pstwo));
        systemName.add(new System("GameCube", R.drawable.gamecube));
        systemName.add(new System("xBox", R.drawable.xbox));
        systemName.add(new System("Wii", R.drawable.wii));
        systemName.add(new System("PS3", R.drawable.psthree));
        systemName.add(new System("xBox 360", R.drawable.xboxthreesixty));
        systemName.add(new System("Wii U", R.drawable.wiiu));
        systemName.add(new System("PS4", R.drawable.psfour));
        systemName.add(new System("DVDs", R.drawable.dvd));
        systemName.add(new System("System Documentation", R.drawable.document));


        SystemAdapter sysAdapter = new SystemAdapter(this, systemName);

        GridView gridView = (GridView) findViewById(R.id.gridView_system);

        gridView.setAdapter(sysAdapter);
        gridView.setNumColumns(3);


        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int systemPosition = position;
                systemPosition+=1;      //1 for atari so easier to check with layout
                long systemID = id;
                // DO something
                if(systemPosition==1) {      //0 INDEX
                    Intent atariIntent = new Intent(MainActivity.this, Atari.class);
                    startActivity(atariIntent);
                }
                if(systemPosition==2){
                    Intent nesIntent = new Intent(MainActivity.this, NES.class);
                    startActivity(nesIntent);
                }
                if(systemPosition==3){
                    Intent genIntent = new Intent(MainActivity.this, Genesis.class);
                    startActivity(genIntent);
                }
                if(systemPosition==4){
                    Intent snesIntent = new Intent(MainActivity.this, SNES.class);
                    startActivity(snesIntent);
                }
                if(systemPosition==5){
                    Intent psOneIntent = new Intent(MainActivity.this, PSOne.class);
                    startActivity(psOneIntent);
                }
                if(systemPosition==6){
                    Intent nSixtyFourIntent = new Intent(MainActivity.this, N64.class);
                    startActivity(nSixtyFourIntent);
                }
                if(systemPosition==7){
                    Intent dreamcastIntent = new Intent(MainActivity.this, Dreamcast.class);
                    startActivity(dreamcastIntent);
                }
                if(systemPosition==8){
                    Intent psTwoIntent = new Intent(MainActivity.this, PSTwo.class);
                    startActivity(psTwoIntent);
                }
                if(systemPosition==9){
                    Intent gameCubeIntent = new Intent(MainActivity.this, GameCube.class);
                    startActivity(gameCubeIntent);
                }
                if(systemPosition==10){
                    Intent xBoxIntent = new Intent(MainActivity.this, XBox.class);
                    startActivity(xBoxIntent);
                }
                if(systemPosition==11){
                    Intent wiiIntent = new Intent(MainActivity.this, Wii.class);
                    startActivity(wiiIntent);
                }
                if(systemPosition==12){
                    Intent psThreeIntent = new Intent(MainActivity.this, PSThree.class);
                    startActivity(psThreeIntent);
                }
                if(systemPosition==13){
                    Intent xBoxThreeSixtyIntent = new Intent(MainActivity.this, XBoxThreeSixty.class);
                    startActivity(xBoxThreeSixtyIntent);
                }
                if(systemPosition==14){
                    Intent wiiUIntent = new Intent(MainActivity.this, WiiU.class);
                    startActivity(wiiUIntent);
                }
                if(systemPosition==15){
                    Intent psFourIntent = new Intent(MainActivity.this, PSFour.class);
                    startActivity(psFourIntent);
                }
                if(systemPosition==16){
                    Intent dvdIntent = new Intent(MainActivity.this, DVD.class);
                    startActivity(dvdIntent);
                }
                if(systemPosition==17){
                    Intent documentIntent = new Intent(MainActivity.this, Documents.class);
                    startActivity(documentIntent);
                }
            }
        });



    }
}

