package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by John on 9/24/2016.
 */
public class Drawings extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawings);
        int drawingNumber =R.drawable.atari;        //dafualt image for testing only
        int blockNumber = getIntent().getIntExtra("Block", 1);
            if (blockNumber ==1){           /// if the intent extra has 1, the
            drawingNumber = R.drawable.etvpageone;}
        int gaNumber = getIntent().getIntExtra("ga", 1);
            if (gaNumber ==2){
            drawingNumber = R.drawable.etvpagetwo;}
        int avNumber = getIntent().getIntExtra("av", 1);
            if (avNumber ==3){
            drawingNumber = R.drawable.etvpagethree;}
        int pc1Number = getIntent().getIntExtra("pc1", 1);
            if (pc1Number ==4){
            drawingNumber = R.drawable.etvpagefour;}
        int pc2Number = getIntent().getIntExtra("pc2", 1);
            if (pc2Number ==5){
            drawingNumber = R.drawable.etvpagefive;}
        int selectionNumber = getIntent().getIntExtra("selection", 1);
            if (selectionNumber ==6){
            drawingNumber = R.drawable.etvpagesix;}
        int sparesNumber = getIntent().getIntExtra("spares", 1);
            if (sparesNumber ==7){
            drawingNumber = R.drawable.etvpageseven;}
        int infoNumber = getIntent().getIntExtra("info", 1);
            if (infoNumber ==8){
            drawingNumber = R.drawable.etvpageeight;}
        int designNumber = getIntent().getIntExtra("design", 1);
            if (designNumber ==9){
            drawingNumber = R.drawable.tetrispageone;}
        int lengthNumber = getIntent().getIntExtra("length", 1);
            if (lengthNumber ==10){
            drawingNumber = R.drawable.tetrispagetwo;}
        int diagramNumber = getIntent().getIntExtra("diagram", 1);
            if (diagramNumber ==11){
            drawingNumber = R.drawable.tetrispagethree;}
        //Toast toast = Toast.makeText(Drawings.this, "the drawing number is "+blockNumber, Toast.LENGTH_LONG);
        //if blockNumber = 1 image is r.id.block
        //toast.show();

        ImageView i = (ImageView)findViewById(R.id.system_drawing);

        i.setImageResource(drawingNumber);
    }


}
