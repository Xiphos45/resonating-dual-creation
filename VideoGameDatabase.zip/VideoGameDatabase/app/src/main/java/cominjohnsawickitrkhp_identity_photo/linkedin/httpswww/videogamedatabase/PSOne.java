package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class PSOne extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_psone);
        ArrayList<Title> psone = new ArrayList<Title>();
        psone.add(new Title(R.drawable.psone, "Army Men: Air Attack", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Army Men: Sarge's Heroes", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Crash Bandicoot", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Crash Bandicoot: Warped", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "CTR (Crash Team Racing)", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Driver", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Driver 2", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Final Fantasy VII", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Final Fantasy VIII", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Final Fantasy IX", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Metal Gear Solid", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "MDK", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Micro Machines V3", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Need for Speed III: High Stakes", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Need for Speed: High Stakes", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Need for Speed Porsche Unleashed", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Nuclear Strike", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Quake II", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Road Rash 3D", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Soviet Strike", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Syphon Filter", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Syphon Filter 2", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Syphon Filter 3", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Tekken 3", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Tomb Raider", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Tomb Raider II", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Tomb Raider III", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Tony Hawk 2", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Twisted Metal 2", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Twisted Metal III", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Twisted Metal 4", "Row 1", "Column 1"));
        psone.add(new Title(R.drawable.psone, "Warhawk", "Row 1", "Column 1"));
        TitleAdapter adapter = new TitleAdapter(this, psone);
        ListView listView = (ListView) findViewById(R.id.list_psone);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int psOnePosition = position;

                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (psOnePosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (psOnePosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}