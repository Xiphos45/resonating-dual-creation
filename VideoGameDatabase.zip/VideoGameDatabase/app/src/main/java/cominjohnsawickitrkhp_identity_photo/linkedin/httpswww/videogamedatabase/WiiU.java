package cominjohnsawickitrkhp_identity_photo.linkedin.httpswww.videogamedatabase;

/**
 * Created by John on 9/22/2016.
 */

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import java.util.ArrayList;

public class WiiU extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_wiiu);
        ArrayList<Title> wiiU = new ArrayList<Title>();
        wiiU.add(new Title(R.drawable.wiiu, "Mario Kart 8", "Row 1 from the top", "Column 6 from the left"));
        wiiU.add(new Title(R.drawable.wiiu, "Super Mario 3D World", "Row 1 from the top", "Column 6 from the left"));
        wiiU.add(new Title(R.drawable.wiiu, "New Super Mario Bros. U", "Row 1 from the top", "Column 6 from the left"));
        wiiU.add(new Title(R.drawable.wiiu, "Donkey King Country Tropical Freeze", "Row 1 from the top", "Column 6 from the left"));

        TitleAdapter adapter = new TitleAdapter(this, wiiU);
        ListView listView = (ListView) findViewById(R.id.list_wiiu);

        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                int wiiUPosition = position;


                Uri webpageAst = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentAst = new Intent(Intent.ACTION_VIEW, webpageAst);
                if (wiiUPosition == 0) {      //0 INDEX
                    startActivity(intentAst);
                }
                Uri webpageMC = Uri.parse("https://en.wikipedia.org/wiki/Missile_Command");
                Intent intentMC = new Intent(Intent.ACTION_VIEW, webpageMC);
                if (wiiUPosition == 1) {      //0 INDEX
                    startActivity(intentMC);
                }
            }
        });





    }
}